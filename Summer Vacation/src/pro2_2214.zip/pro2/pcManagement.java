package pro2;

import java.sql.*;
import java.util.*;

class pcManagement {
	Scanner sc=new Scanner(System.in);

	String id;
	String password;
	String payment;
	
	pcManagement() {
		Connection conn=null;
		PreparedStatement pstmt = null;
		
		//DB
		try {
			Class.forName("org.gjt.mm.mysql.Driver").newInstance();
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/javap", "root", "mirim2");
			System.out.println("DB ���� �Ϸ�");
		}catch(SQLException ex) {
			System.out.println("SQLException:" + ex);
		}catch(Exception ex) {
			System.out.println("Exception:" + ex);
		}
	}
		
	
	public void pcManagement() {
		Login login = new Login();
		Join join = new Join();
		Use use = new Use();
		
		
		System.out.println("pc���� ���α׷�");
		System.out.print("����Ͻ� pc�� �����ϼ���(1~6) : ");
		int u = sc.nextInt();
		System.out.println("�α��� : 1, ȸ������ : 0");
		int n=sc.nextInt();
		boolean bl = false;
		if(n == 1) {
			id = sc.next();
			password = sc.next();
			bl = login.Login(id, password);
		}
		else if(n == 0) {
			String name = sc.next();
			id = sc.next();
			password = sc.next();
			System.out.println("����? �ĺ�?");
			payment = sc.next();
			bl = join.join(name, id, password, payment);
		}
		if(bl == true) {
			System.out.println("ȯ���մϴ�.");
			use.use(id, password);
		}
	}
	
	public static void main(String[] args) {
		
		pcManagement pm = new pcManagement();

	}

}


	


