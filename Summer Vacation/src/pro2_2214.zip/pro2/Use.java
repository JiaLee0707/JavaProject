package pro2;

import java.sql.*;
import java.util.*;

class Use {
	public void use(String id, String password) {
		Connection conn=null;
		PreparedStatement pstmt = null;
		
		Scanner sc=new Scanner(System.in);
		try {
			String sql = "select * from pcmember where id = ?, password =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, password);
			
			ResultSet srs = pstmt.executeQuery();
			while(srs.next()) {
				if(id == srs.getString("id") && password == srs.getString("ps")) {
					if(srs.getString("payment").equals("����")) {
						System.out.println("��ð��� �����ðڽ��ϱ�?(1�ð��� 1000��)(����:60��)");
						String time=sc.next();
						int t = Integer.parseInt(time);
						int count;
						for(count=0; t >=60; count++) {
							t-=60;
						}
						String money = Integer.toString(count*1000);
						sql = "update pcmember set time = ?, money = ? where id = ?";
						pstmt = conn.prepareStatement(sql);
						pstmt.setString(1, time);
						pstmt.setString(2, money);
						pstmt.setString(3, id);
						pstmt.executeUpdate(); //�����Ű�� ��
						
						sql = "select * from pcmember";
						pstmt = conn.prepareStatement(sql);
						srs = pstmt.executeQuery();
					}
					else if(srs.getString("payment").equals("�ĺ�")) {
						System.out.println("���Ḧ ���Ͻø� 0�� ��������");
						//timer.run("after");
						//int n=sc.nextInt();
					}
				}
			}
		}catch(SQLException ex) {
			System.out.println("SQLException:" + ex);
		}catch(Exception ex) {
			System.out.println("Exception:" + ex);
		}
	}
}
