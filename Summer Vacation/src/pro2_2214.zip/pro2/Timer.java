package pro2;

import java.util.*;

abstract class Timer implements Runnable{
	private static Thread timer = null;
	
	public String after() {
		int hour = 0 , min = 0, second = 0;
		
		second++;
		if(second >= 60) {
			second=0;
			min++;
		}
		String clockText = Integer.toString(hour);
		clockText = clockText.concat(":");
		clockText = clockText.concat(Integer.toString(min));
		clockText = clockText.concat(":");
		clockText = clockText.concat(Integer.toString(second));
		return clockText;	
	}
	
	public String first() {
		int hour = 0 , min = 0, second = 0;
		
		second++;
		if(second >= 60) {
			second=0;
			min++;
		}
		String clockText = Integer.toString(hour);
		clockText = clockText.concat(":");
		clockText = clockText.concat(Integer.toString(min));
		clockText = clockText.concat(":");
		clockText = clockText.concat(Integer.toString(second));
		return clockText;	
	}

	public void run(String way) {
		while(true) {
			try {
				Thread.sleep(1000);
			}
			catch(InterruptedException e) {
				return;
			}
			if(way.equals("after")) {
				System.out.println(after());
			}
			else if(way.equals("first")) {
				System.out.println(first());
			}
		}
		
	}
}