package pro2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

class Login {
	public boolean Login(String id, String ps) {
		Connection conn=null;
		PreparedStatement pstmt = null;
		
		try {
			String sql = "select * from pcmember";
			pstmt = conn.prepareStatement(sql);
			ResultSet srs = pstmt.executeQuery();
			while(srs.next()) {
				if(id == srs.getString("id") && ps == srs.getString("ps")) {
					return true;
				}
				else continue;
			}
		}catch(SQLException ex) {
			System.out.println("SQLException:" + ex);
		}catch(Exception ex) {
			System.out.println("Exception:" + ex);
		}
		return false;
	}
}