package JAVA_0723;

import java.util.*;

public class Person {
	String name;
	String id;
	
	public Person(String name) {
		this.name = name;
	}
}
