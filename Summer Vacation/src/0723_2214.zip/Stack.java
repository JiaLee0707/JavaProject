package JAVA_0723;

interface Stack {
	public int length();
	public int capacity();
	public String pop();
	public boolean push(String val);
}
