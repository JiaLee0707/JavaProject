package JAVA_0723;

import java.util.*;

public class Student extends Person{
	String grade;
	String department;
	
	public Student(String name) {
		super(name);
	}
}
